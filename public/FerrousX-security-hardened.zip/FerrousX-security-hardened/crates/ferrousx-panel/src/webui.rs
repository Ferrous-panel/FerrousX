//! crates/ferrousx-panel/src/webui.rs
//! Máy chủ Giao diện Quản trị Web Nội bộ (Embedded Zero-Dependency Rust Web Dashboard) đã gia cố bảo mật:
//!   - Bắt buộc xác thực Bearer Token / `X-FerrousX-Token` (so sánh thời gian hằng số với `/etc/ferrousx/admin.token`)
//!   - Chống Brute-Force theo IP với cơ chế khóa tạm thời
//!   - Kiểm tra `Origin` / CSRF trên mọi thao tác thay đổi trạng thái (`POST /api/reload`)
//!   - Đính kèm đầy đủ Security Headers (`Content-Security-Policy`, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`)
//!   - Không rò rỉ đường dẫn hệ thống nội bộ khi chưa xác thực

use std::collections::HashMap;
use std::net::{IpAddr, SocketAddr};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use anyhow::Result;
use ferrousx_config::config::ConfigManager;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tracing::{error, info, warn};

use crate::api::{constant_time_eq, load_or_init_admin_token};

/// Giao diện HTML/CSS/JS Tích hợp sẵn (Single-Binary Embedded WebUI) có hỗ trợ nhập Admin Token bảo mật
const DASHBOARD_HTML: &str = r#"<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FerrousX Control Plane — Pure Rust Dashboard</title>
    <style>
        :root { --bg: #090d16; --card: #111827; --border: #1f2937; --accent: #10b981; --text: #f3f4f6; --muted: #9ca3af; }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, monospace; }
        body { background: var(--bg); color: var(--text); padding: 2rem; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); padding-bottom: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
        .badge { background: rgba(16, 185, 129, 0.15); color: var(--accent); border: 1px solid var(--accent); padding: 0.25rem 0.75rem; border-radius: 4px; font-size: 0.85rem; }
        .auth-bar { display: flex; gap: 0.5rem; align-items: center; }
        .auth-input { background: #1f2937; color: var(--text); border: 1px solid #374151; padding: 0.5rem 0.75rem; border-radius: 4px; width: 260px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1.25rem; margin-bottom: 2rem; }
        .card { background: var(--card); border: 1px solid var(--border); border-radius: 6px; padding: 1.25rem; }
        .card h3 { color: var(--muted); font-size: 0.8rem; text-transform: uppercase; margin-bottom: 0.5rem; }
        .card .val { font-size: 1.6rem; font-weight: 700; color: var(--accent); }
        .btn { background: var(--accent); color: #000; border: none; padding: 0.6rem 1.2rem; border-radius: 4px; font-weight: 700; cursor: pointer; }
        .btn:hover { opacity: 0.9; }
        pre { background: var(--card); border: 1px solid var(--border); padding: 1rem; border-radius: 6px; overflow-x: auto; color: #cbd5e1; }
    </style>
</head>
<body>
    <div class="header">
        <div>
            <h1>FerrousX Native Rust Engine</h1>
            <p style="color: var(--muted); font-size: 0.9rem;">Hardened Zero-Allocation HTTP/1.1 + HTTP/2 + HTTP/3 QUIC + WAF</p>
        </div>
        <div class="auth-bar">
            <input id="admin-token" class="auth-input" type="password" placeholder="Nhập /etc/ferrousx/admin.token" />
            <button class="btn" onclick="refreshStatus()">Xác thực</button>
            <button class="btn" onclick="triggerReload()">⚡ Hot-Reload (RCU)</button>
            <span class="badge" id="auth-state">LOCKED</span>
        </div>
    </div>
    <div class="grid">
        <div class="card"><h3>RCU Config Epoch</h3><div class="val" id="epoch">-</div></div>
        <div class="card"><h3>Virtual Hosts</h3><div class="val" id="vhosts">-</div></div>
        <div class="card"><h3>Upstream Pools</h3><div class="val" id="upstreams">-</div></div>
        <div class="card"><h3>WAF & QUIC Shield</h3><div class="val" id="quic">ACTIVE</div></div>
    </div>
    <h3 style="margin-bottom: 0.75rem; color: var(--muted);">TRẠNG THÁI CẤU HÌNH ĐANG HOẠT ĐỘNG:</h3>
    <pre id="raw-json">Vui lòng nhập Admin Token từ /etc/ferrousx/admin.token để truy vấn dữ liệu...</pre>
    <script>
        function getHeaders() {
            const tok = document.getElementById('admin-token').value.trim();
            return tok ? { 'X-FerrousX-Token': tok } : {};
        }
        async function refreshStatus() {
            try {
                const res = await fetch('/api/status', { headers: getHeaders() });
                const data = await res.json();
                if (!res.ok) {
                    document.getElementById('auth-state').innerText = 'UNAUTHORIZED';
                    document.getElementById('raw-json').innerText = JSON.stringify(data, null, 2);
                    return;
                }
                document.getElementById('auth-state').innerText = 'VERIFIED';
                document.getElementById('epoch').innerText = 'v' + data.epoch;
                document.getElementById('vhosts').innerText = data.vhosts_count;
                document.getElementById('upstreams').innerText = data.upstreams_count;
                document.getElementById('quic').innerText = data.waf_enabled ? ('WAF ' + data.waf_mode) : 'QUIC READY';
                document.getElementById('raw-json').innerText = JSON.stringify(data, null, 2);
            } catch (e) {}
        }
        async function triggerReload() {
            const res = await fetch('/api/reload', { method: 'POST', headers: getHeaders() });
            const data = await res.json();
            await refreshStatus();
        }
    </script>
</body>
</html>"#;

struct WebUiBruteForceTracker {
    attempts: Mutex<HashMap<IpAddr, (u32, Instant)>>,
    max_attempts: u32,
    lockout_dur: Duration,
}

impl WebUiBruteForceTracker {
    fn new(max_attempts: u32, lockout_secs: u64) -> Self {
        Self {
            attempts: Mutex::new(HashMap::new()),
            max_attempts: max_attempts.max(3),
            lockout_dur: Duration::from_secs(lockout_secs.max(30)),
        }
    }

    fn is_locked(&self, ip: IpAddr) -> bool {
        let Ok(mut map) = self.attempts.lock() else {
            return false;
        };
        if let Some((cnt, ts)) = map.get(&ip) {
            if *cnt >= self.max_attempts {
                if ts.elapsed() < self.lockout_dur {
                    return true;
                }
                map.remove(&ip);
            }
        }
        false
    }

    fn record_fail(&self, ip: IpAddr) {
        if let Ok(mut map) = self.attempts.lock() {
            let entry = map.entry(ip).or_insert((0, Instant::now()));
            entry.0 = entry.0.saturating_add(1);
            entry.1 = Instant::now();
        }
    }

    fn record_ok(&self, ip: IpAddr) {
        if let Ok(mut map) = self.attempts.lock() {
            map.remove(&ip);
        }
    }
}

/// Khởi chạy máy chủ HTTP nội bộ phục vụ Web Dashboard của FerrousX
pub async fn start_embedded_webui_server(
    bind_addr: &str,
    config_mgr: Arc<ConfigManager>,
) -> Result<()> {
    let addr: SocketAddr = bind_addr.parse()?;
    let listener = TcpListener::bind(addr).await?;

    let cfg = config_mgr.current();
    let admin_token = Arc::new(
        load_or_init_admin_token(&cfg.admin_security.token_file_path)
            .unwrap_or_else(|_| String::new()),
    );
    let tracker = Arc::new(WebUiBruteForceTracker::new(
        cfg.admin_security.max_failed_attempts,
        cfg.admin_security.brute_force_lockout_secs,
    ));

    info!(
        %addr,
        "Embedded Rust WebUI Dashboard đã sẵn sàng tại http://{} (Yêu cầu xác thực Admin Token)",
        addr
    );

    loop {
        match listener.accept().await {
            Ok((stream, peer_addr)) => {
                let mgr = Arc::clone(&config_mgr);
                let tok = Arc::clone(&admin_token);
                let trk = Arc::clone(&tracker);
                tokio::spawn(async move {
                    if let Err(e) =
                        handle_webui_client(stream, peer_addr.ip(), mgr, tok, trk).await
                    {
                        error!(error = %e, "Lỗi xử lý kết nối WebUI");
                    }
                });
            }
            Err(e) => error!(error = %e, "Lỗi accept kết nối WebUI"),
        }
    }
}

/// Trích xuất Token từ header `X-FerrousX-Token` hoặc `Authorization: Bearer <token>`
fn extract_token_from_headers(req_text: &str) -> Option<String> {
    for line in req_text.lines().skip(1) {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            break;
        }
        if let Some((k, v)) = trimmed.split_once(':') {
            let key = k.trim();
            let val = v.trim();
            if key.eq_ignore_ascii_case("x-ferrousx-token") && !val.is_empty() {
                return Some(val.to_string());
            }
            if key.eq_ignore_ascii_case("authorization") {
                if let Some(bearer) = val
                    .strip_prefix("Bearer ")
                    .or_else(|| val.strip_prefix("bearer "))
                {
                    if !bearer.trim().is_empty() {
                        return Some(bearer.trim().to_string());
                    }
                }
            }
        }
    }
    None
}

/// Kiểm tra Origin header chống CSRF khi gọi API thay đổi trạng thái (`POST /api/reload`)
fn verify_origin_allowed(req_text: &str, allowed_origins: &[String]) -> bool {
    for line in req_text.lines().skip(1) {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            break;
        }
        if let Some((k, v)) = trimmed.split_once(':') {
            if k.trim().eq_ignore_ascii_case("origin") {
                let origin = v.trim();
                return allowed_origins
                    .iter()
                    .any(|allowed| allowed.eq_ignore_ascii_case(origin));
            }
        }
    }
    // Cho phép CLI cục bộ (curl trên 127.0.0.1) không gửi Origin header nhưng có gửi đúng Admin Token
    true
}

async fn handle_webui_client(
    mut stream: TcpStream,
    peer_ip: IpAddr,
    config_mgr: Arc<ConfigManager>,
    expected_token: Arc<String>,
    tracker: Arc<WebUiBruteForceTracker>,
) -> Result<()> {
    let mut buf = [0u8; 8192];
    let Ok(Ok(n)) = tokio::time::timeout(Duration::from_secs(5), stream.read(&mut buf)).await
    else {
        return Ok(());
    };
    if n == 0 {
        return Ok(());
    }

    let req_str = String::from_utf8_lossy(&buf[..n]);
    let first_line = req_str.lines().next().unwrap_or("");
    let mut parts = first_line.split_whitespace();
    let method = parts.next().unwrap_or("GET");
    let path = parts.next().unwrap_or("/");

    // Trang HTML khung giao diện tĩnh (không chứa dữ liệu nhạy cảm cho tới khi nhập Token)
    if method == "GET" && (path == "/" || path == "/index.html") {
        write_secure_response(
            &mut stream,
            "200 OK",
            "text/html; charset=utf-8",
            DASHBOARD_HTML.as_bytes(),
        )
        .await?;
        return Ok(());
    }

    // Mọi endpoint `/api/*` đều bắt buộc kiểm tra Brute-Force Lockout & Admin Token
    if tracker.is_locked(peer_ip) {
        let body = br#"{"success":false,"error":"429 Too Many Requests: IP Locked Out"}"#;
        write_secure_response(
            &mut stream,
            "429 Too Many Requests",
            "application/json; charset=utf-8",
            body,
        )
        .await?;
        return Ok(());
    }

    let cfg = config_mgr.current();
    let provided = extract_token_from_headers(&req_str);
    let is_authenticated = match provided {
        Some(ref tok) if !expected_token.is_empty() => {
            constant_time_eq(tok.as_bytes(), expected_token.as_bytes())
        }
        _ => false,
    };

    if !is_authenticated {
        tracker.record_fail(peer_ip);
        warn!(%peer_ip, path, "Chặn truy cập API WebUI không có Admin Token hợp lệ");
        let body = br#"{"success":false,"error":"401 Unauthorized: Missing or Invalid X-FerrousX-Token"}"#;
        write_secure_response(
            &mut stream,
            "401 Unauthorized",
            "application/json; charset=utf-8",
            body,
        )
        .await?;
        return Ok(());
    }
    tracker.record_ok(peer_ip);

    let (status_line, content_type, body) = match (method, path) {
        ("GET", "/api/status") => {
            let vhosts: Vec<String> = cfg.vhosts.iter().map(|v| v.server_name.clone()).collect();
            let json = serde_json::json!({
                "status": "online",
                "engine": "FerrousX Hardened Native Rust",
                "epoch": cfg.version_epoch,
                "bind_http_addr": cfg.bind_http_addr,
                "bind_https_addr": cfg.bind_https_addr,
                "bind_udp_addr": cfg.bind_udp_addr,
                "quic_enabled": cfg.enable_http3_quic,
                "waf_enabled": cfg.waf.enabled,
                "waf_mode": format!("{:?}", cfg.waf.mode),
                "vhosts_count": cfg.vhosts.len(),
                "upstreams_count": cfg.upstreams.len(),
                "vhosts": vhosts,
            });
            ("200 OK", "application/json; charset=utf-8", json.to_string())
        }
        ("POST", "/api/reload") => {
            if !verify_origin_allowed(&req_str, &cfg.admin_security.cors_allowed_origins) {
                (
                    "403 Forbidden",
                    "application/json; charset=utf-8",
                    r#"{"success":false,"message":"403 Forbidden: Origin Rejected by CSRF/CORS Policy"}"#
                        .to_string(),
                )
            } else {
                match config_mgr.reload_from_disk() {
                    Ok(new_epoch) => {
                        let json = serde_json::json!({
                            "success": true,
                            "message": format!("Hot-Reload RCU thành công! Epoch hiện tại: v{new_epoch}"),
                            "epoch": new_epoch
                        });
                        ("200 OK", "application/json; charset=utf-8", json.to_string())
                    }
                    Err(e) => {
                        warn!(error = %e, "WebUI Reload thất bại");
                        let json = serde_json::json!({
                            "success": false,
                            "message": "Không thể nạp cấu hình mới (vui lòng kiểm tra nhật ký hệ thống)"
                        });
                        (
                            "400 Bad Request",
                            "application/json; charset=utf-8",
                            json.to_string(),
                        )
                    }
                }
            }
        }
        _ => (
            "404 Not Found",
            "application/json; charset=utf-8",
            r#"{"error":"Not Found"}"#.to_string(),
        ),
    };

    write_secure_response(&mut stream, status_line, content_type, body.as_bytes()).await?;
    Ok(())
}

async fn write_secure_response(
    stream: &mut TcpStream,
    status_line: &str,
    content_type: &str,
    body: &[u8],
) -> Result<()> {
    let response_head = format!(
        "HTTP/1.1 {status_line}\r\n\
         Content-Type: {content_type}\r\n\
         Content-Length: {}\r\n\
         Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'\r\n\
         X-Frame-Options: DENY\r\n\
         X-Content-Type-Options: nosniff\r\n\
         Referrer-Policy: no-referrer\r\n\
         Cache-Control: no-store\r\n\
         Connection: close\r\n\r\n",
        body.len()
    );

    stream.write_all(response_head.as_bytes()).await?;
    stream.write_all(body).await?;
    stream.shutdown().await?;
    Ok(())
}
